import React from "react";

const Footer = () => {
  return (
    <footer>
      <p style={{ color: "rgb(100 116 139)", fontWeight: "500" }}>&copy;2023 Fadli Rizaldy | All Rights Reserved</p>
    </footer>
  );
};

export default Footer;
